import React, { createContext, useContext, useState, useEffect, ReactNode, useCallback, useRef } from 'react';
import { supabase, TENANT_HEADER_KEYS } from '@/integrations/supabase/client';
import { User } from '@supabase/supabase-js';

export interface Profile { // Adicionado export
  id: string;
  email: string;
  role: string;
  full_name?: string;
  avatar_url?: string;
  status?: string;
  created_at: string;
  updated_at: string;
}

interface AuthContextType {
  user: User | null;
  currentUser: Profile | null;
  loading: boolean;
  isSuperAdmin: boolean;
  signIn: (email: string, password: string) => Promise<{ error: any }>;
  signUp: (email: string, password: string, userData?: any) => Promise<{ error: any }>;
  signInWithGoogle: () => Promise<{ error: any }>;
  signOut: () => Promise<void>;
  updateProfile: (updates: Partial<Profile>) => Promise<{ error: any }>;
  setCurrentUser: (user: Profile | null) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const SUPER_ADMIN_EMAILS = (import.meta.env.VITE_SUPER_ADMIN_EMAILS ?? 'joabychaves10@gmail.com')
  .split(',')
  .map(email => email.trim().toLowerCase())
  .filter(Boolean);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

// Função para determinar o redirect URL correto baseado no ambiente e subdomínio
const getRedirectUrl = (): string => {
  const { origin, hostname, protocol } = window.location;

  // Ambiente local (localhost ou 127.0.0.1)
  if (hostname === 'localhost' || hostname === '127.0.0.1') {
    return `${origin}/auth/callback`;
  }

  // Ambiente de desenvolvimento Netlify (ex: delliapp.netlify.app)
  if (hostname.endsWith('netlify.app')) {
    return `${origin}/auth/callback`;
  }

  // Produção - delliapp.com.br com subdomínios (tld .com.br)
  const parts = hostname.split('.');
  const isDelliappDomain =
    parts.length >= 3 &&
    parts[parts.length - 3] === 'delliapp' &&
    parts[parts.length - 2] === 'com' &&
    parts[parts.length - 1] === 'br';

  if (isDelliappDomain) {
    return `${protocol}//${hostname}/auth/callback`;
  }

  // Fallback para o domínio atual (caso geral ou configuração não prevista)
  return `${origin}/auth/callback`;
};

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [currentUser, setCurrentUser] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);
  const NO_TEAM_SENTINEL = '00000000-0000-0000-0000-000000000000';
  const startedSessionRef = useRef<boolean>(false);

  const KEY = (scope: string) => `sess_${scope}`;
  const currentScope = (subdomain?: string | null) => (subdomain && subdomain.trim() !== '' ? subdomain.trim() : 'master');
  const getSubdomainFromHost = (): string | null => {
    try {
      const hostname = window.location.hostname;
      if (hostname === 'localhost' || hostname === '127.0.0.1') return null;
      const parts = hostname.split('.');
      const isDelliappDomain = parts.length >= 3 && parts[parts.length - 3] === 'delliapp' && parts[parts.length - 2] === 'com' && parts[parts.length - 1] === 'br';
      if (!isDelliappDomain) return null;
      const sub = parts[0];
      return sub === 'app' ? null : sub;
    } catch {
      return null;
    }
  };


  const configureRlsForUser = useCallback(async (sessionUser: User | null) => {
    try {
      const email = sessionUser?.email?.toLowerCase();
      const isSuper = email ? SUPER_ADMIN_EMAILS.includes(email) : false;

      if (!isSuper) {
        return;
      }

      const { error: roleError } = await supabase.rpc('set_app_config', {
        config_name: 'app.current_user_role',
        config_value: 'general_admin'
      });

      if (roleError) {
        console.warn('Falha ao configurar role para super admin:', roleError);
      }

      const { error: teamError } = await supabase.rpc('set_app_config', {
        config_name: 'app.current_team_id',
        config_value: NO_TEAM_SENTINEL
      });

      if (teamError) {
        console.warn('Falha ao limpar team_id para super admin:', teamError);
      }
    } catch (error) {
      console.warn('Erro ao configurar RLS para super admin:', error);
    }
  }, []);

  useEffect(() => {
    const emailFromUser = user?.email?.toLowerCase();
    const emailFromProfile = currentUser?.email?.toLowerCase();
    const resolvedEmail = emailFromUser || emailFromProfile;
    setIsSuperAdmin(resolvedEmail ? SUPER_ADMIN_EMAILS.includes(resolvedEmail) : false);
  }, [user, currentUser]);

  useEffect(() => {
    let isMounted = true;
    setLoading(true);

    // Renomeada para clareza e para retornar a sessão ou nulo
    const initializeSession = async (): Promise<User | null> => {
      try {
        console.log('Inicializando sessão (initializeSession)...');
        const { data: { session: activeSession }, error } = await supabase.auth.getSession();

        if (!isMounted) return null;

        if (error) {
          console.error('Erro ao obter sessão (initializeSession):', error);
          setUser(null);
          setCurrentUser(null);
          return null;
        }

        if (activeSession?.user) {
          console.log('Sessão ativa encontrada (initializeSession):', activeSession.user.id);
          setUser(activeSession.user);
          // Configurações que tocam no Supabase devem ser adiadas para evitar deadlocks
          setTimeout(() => {
            configureRlsForUser(activeSession.user);
            fetchUserProfile(activeSession.user.id);
          }, 0);
          return activeSession.user;
        } else {
          console.log('Nenhuma sessão ativa ou usuário na sessão (initializeSession).');
          setUser(null);
          setCurrentUser(null);
          return null;
        }
      } catch (e) {
        console.error("Erro em initializeSession:", e);
        if (isMounted) {
          setUser(null);
          setCurrentUser(null);
        }
        return null;
      }
    };

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (!isMounted) return;
      console.log('Evento de autenticação:', event, session?.user?.id);

      // INITIAL_SESSION é tratado pela chamada inicial a initializeSession().
      // O listener aqui reage somente a mudanças após a inicialização.
      if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED') {
        setUser(session?.user ?? null);
        if (session?.user) {
          // Evitar chamadas ao Supabase dentro do callback para não travar o app
          setTimeout(() => {
            configureRlsForUser(session.user);
            fetchUserProfile(session.user.id);
          }, 0);
        } else {
          setCurrentUser(null);
        }
      } else if (event === 'SIGNED_OUT') {
        setUser(null);
        setCurrentUser(null);
        startedSessionRef.current = false;
        setLoading(false); // Estado final quando desloga
      } else if (event === 'USER_UPDATED') {
        setUser(session?.user ?? null);
        if (session?.user) {
          setTimeout(() => {
            fetchUserProfile(session.user.id);
          }, 0);
        } else {
          setCurrentUser(null);
        }
      }
    });

    initializeSession().finally(() => {
      if (isMounted) {
        setLoading(false);
      }
    });

    return () => {
      isMounted = false;
      subscription.unsubscribe();
    };
  }, []);

  const fetchUserProfile = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single<Profile>(); // Adiciona a tipagem explícita aqui

      if (error) {
        console.error('Erro ao buscar perfil:', error);
        setCurrentUser(null); // Limpa o usuário em caso de erro
        return;
      }

      if (data) {
        setCurrentUser(data); // Agora 'data' deve estar corretamente tipado
      } else {
        setCurrentUser(null); // Caso data seja null
      }
    } catch (error) {
      console.error('Erro ao buscar perfil:', error);
      setCurrentUser(null);
    }
  };

  const signIn = async (email: string, password: string) => {
    try {
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      return { error };
    } catch (error) {
      return { error };
    }
  };

  const signInWithGoogle = async () => {
    try {
      const redirectUrl = getRedirectUrl();
      console.log('Redirecionando Google OAuth para:', redirectUrl);
      
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: redirectUrl,
          queryParams: {
            access_type: 'offline',
            prompt: 'select_account'
          }
        }
      });
      
      return { error };
    } catch (error) {
      return { error };
    }
  };

  const signUp = async (email: string, password: string, userData?: any) => {
    try {
      const redirectUrl = getRedirectUrl();
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: userData,
          emailRedirectTo: redirectUrl,
        },
      });
      return { error };
    } catch (error) {
      return { error };
    }
  };

  const signOut = async () => {
    try {
      await supabase.auth.signOut();
    } catch (error) {
      console.error('Erro ao fazer logout:', error);
    }
  };

  const updateProfile = async (updates: Partial<Profile>) => {
    if (!user) {
      return { error: 'Usuário não autenticado' };
    }

    try {
      const { error } = await supabase
        .from('profiles')
        .update(updates)
        .eq('id', user.id);

      if (!error) {
        setCurrentUser(prev => prev ? { ...prev, ...updates } : null);
      }

      return { error };
    } catch (error) {
      return { error };
    }
  };

  const value: AuthContextType = {
    user,
    currentUser,
    loading,
    isSuperAdmin,
    signIn,
    signUp,
    signInWithGoogle,
    signOut,
    updateProfile,
    setCurrentUser,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};