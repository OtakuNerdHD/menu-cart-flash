
import React from 'react';
import OrderManagementComponent from '@/components/OrderManagement';

// Este arquivo atua apenas como um wrapper para o componente real
const OrderManagement = () => {
  return <OrderManagementComponent />;
};

export default OrderManagement;
